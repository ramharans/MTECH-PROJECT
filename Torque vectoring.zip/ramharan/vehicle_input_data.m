m=356
Izz=120
c_yf=15714
c_yr=21429
l_f=0.873
l_r=0.717
VCG=25
delta=1.04	
dt=0.001
%% 
% The below code to be run after simulink simulation 
% individually for the models.here x2 and y2 is
% are the co ordinates for without torque vectoring model
% x=out.x2_axis;
% y=out.y2_axis;
% plot(x,y)